package web.team.one;

public class CartDTO {
	
	private int cnum;
	private int pnum;
	private int mnum;
	private int ccount;
	private String pname;
	
	public int getCnum() {
		return cnum;
	}
	public void setCnum(int cnum) {
		this.cnum = cnum;
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public int getMnum() {
		return mnum;
	}
	public void setMnum(int mnum) {
		this.mnum = mnum;
	}
	public int getCcount() {
		return ccount;
	}
	public void setCcount(int ccount) {
		this.ccount = ccount;
	}
	
	public String getPname() {return pname;}
	public void setPname(String pname) {this.pname = pname;}
	
	
	
	
}
