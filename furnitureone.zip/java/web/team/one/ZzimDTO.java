package web.team.one;

public class ZzimDTO {
	private int pnum;
	private int mnum;
	private int zcon;
	
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public int getMnum() {
		return mnum;
	}
	public void setMnum(int mnum) {
		this.mnum = mnum;
	}
	public int getZcon() {
		return zcon;
	}
	public void setZcon(int zcon) {
		this.zcon = zcon;
	}
	
	
	
}
